"use client"
import React, { useState } from 'react';
import { Home, Building, Users, Briefcase, Key, Search, Shield, Truck, FileText, Video, Clock, Star, MapPin, Phone, Mail } from 'lucide-react';

const ServicesPage = () => {
  const [activeTab, setActiveTab] = useState('properties');

  const propertyTypes = [
    {
      icon: <Home className="w-8 h-8" />,
      title: "Family House",
      count: "122 Properties",
      description: "2-5 bedroom houses with garden & parking",
      gradient: "from-blue-500 to-purple-600"
    },
    {
      icon: <Building className="w-8 h-8" />,
      title: "House & Villa",
      count: "155 Properties", 
      description: "Independent houses & luxury villas",
      gradient: "from-green-500 to-teal-600"
    },
    {
      icon: <Key className="w-8 h-8" />,
      title: "Apartment",
      count: "300 Properties",
      description: "1-4 bedroom apartments & penthouses",
      gradient: "from-orange-500 to-red-600"
    },
    {
      icon: <Briefcase className="w-8 h-8" />,
      title: "Office & Studio",
      count: "80 Properties",
      description: "Commercial offices & co-working spaces",
      gradient: "from-purple-500 to-pink-600"
    },
    {
      icon: <Building className="w-8 h-8" />,
      title: "Villa & Condo",
      count: "80 Properties",
      description: "Gated community & luxury condos",
      gradient: "from-cyan-500 to-blue-600"
    }
  ];

  const additionalServices = [
    {
      icon: <Users className="w-6 h-6" />,
      title: "Roommate Matching",
      description: "Find verified roommates and split rent options",
      features: ["Verified profiles", "Compatibility matching", "Split rent calculator"]
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Property Management",
      description: "Complete property management solutions",
      features: ["24/7 maintenance", "Utility management", "Tenant screening"]
    },
    {
      icon: <Truck className="w-6 h-6" />,
      title: "Moving Services",
      description: "Hassle-free relocation assistance",
      features: ["Packing & unpacking", "Transportation", "Storage solutions"]
    },
    {
      icon: <FileText className="w-6 h-6" />,
      title: "Legal Support",
      description: "Professional legal assistance",
      features: ["Agreement drafting", "Documentation help", "Dispute resolution"]
    },
    {
      icon: <Video className="w-6 h-6" />,
      title: "Virtual Tours",
      description: "Experience properties remotely",
      features: ["360° viewing", "Video walkthroughs", "AR visualization"]
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Instant Booking",
      description: "Quick and secure booking process",
      features: ["Quick approval", "Digital contracts", "Online payments"]
    }
  ];

  const stats = [
    { number: "10,000+", label: "Happy Customers", icon: <Star className="w-5 h-5" /> },
    { number: "737", label: "Total Properties", icon: <Home className="w-5 h-5" /> },
    { number: "50+", label: "Cities Covered", icon: <MapPin className="w-5 h-5" /> },
    { number: "24/7", label: "Support Available", icon: <Phone className="w-5 h-5" /> }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Home className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">RentApp</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="text-gray-600 hover:text-gray-900 transition-colors">
                <Phone className="w-5 h-5" />
              </button>
              <button className="text-gray-600 hover:text-gray-900 transition-colors">
                <Mail className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 py-20">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Our <span className="text-yellow-400">Services</span>
          </h2>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl mx-auto">
            Discover the perfect home with our comprehensive rental services. From family houses to luxury villas, we have everything you need.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-gray-900 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors">
              Browse Properties
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-gray-900 transition-colors">
              Contact Us
            </button>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="flex items-center justify-center mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                    {stat.icon}
                  </div>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('properties')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'properties'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Property Types
            </button>
            <button
              onClick={() => setActiveTab('services')}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === 'services'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Additional Services
            </button>
          </nav>
        </div>
      </div>

      {/* Property Types Section */}
      {activeTab === 'properties' && (
        <div className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Property Types
              </h3>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Choose from our wide range of property types to find your perfect home
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {propertyTypes.map((property, index) => (
                <div key={index} className="group">
                  <div className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden transform hover:-translate-y-2">
                    <div className={`h-32 bg-gradient-to-br ${property.gradient} flex items-center justify-center`}>
                      <div className="text-white group-hover:scale-110 transition-transform duration-300">
                        {property.icon}
                      </div>
                    </div>
                    <div className="p-6">
                      <h4 className="text-xl font-bold text-gray-900 mb-2">{property.title}</h4>
                      <div className="text-2xl font-bold text-blue-600 mb-3">{property.count}</div>
                      <p className="text-gray-600 mb-4">{property.description}</p>
                      <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-2 px-4 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-300">
                        View Properties
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Additional Services Section */}
      {activeTab === 'services' && (
        <div className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                Additional Services
              </h3>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Comprehensive support services to make your rental experience seamless
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {additionalServices.map((service, index) => (
                <div key={index} className="bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-6 group hover:-translate-y-1">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                      {service.icon}
                    </div>
                    <h4 className="text-xl font-bold text-gray-900 ml-3">{service.title}</h4>
                  </div>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Find Your Perfect Home?
          </h3>
          <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who found their dream home with RentApp
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-gray-900 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors">
              Get Started Today
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-gray-900 transition-colors">
              Schedule a Call
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Home className="w-5 h-5 text-white" />
                </div>
                <h5 className="text-xl font-bold">RentApp</h5>
              </div>
              <p className="text-gray-400">
                Your trusted partner for finding the perfect rental property.
              </p>
            </div>
            <div>
              <h6 className="text-lg font-semibold mb-4">Services</h6>
              <ul className="space-y-2 text-gray-400">
                <li>Property Search</li>
                <li>Rental Management</li>
                <li>Legal Support</li>
                <li>Moving Services</li>
              </ul>
            </div>
            <div>
              <h6 className="text-lg font-semibold mb-4">Properties</h6>
              <ul className="space-y-2 text-gray-400">
                <li>Family Houses</li>
                <li>Apartments</li>
                <li>Villas</li>
                <li>Commercial</li>
              </ul>
            </div>
            <div>
              <h6 className="text-lg font-semibold mb-4">Contact</h6>
              <ul className="space-y-2 text-gray-400">
                <li>+92 123 456 7890</li>
                <li>info@rentapp.com</li>
                <li>Rawalpindi, Pakistan</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 RentApp. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ServicesPage;