import React from 'react'
import Navbar from './components/Navbar'
import MainHerro from './components/MainHerro'
import PropertyType from './components/PropertyType'
import OurAward from './components/OurAward'
import Location from './components/Location'
import FeatureAgent from './components/FeatureAgent'
import PricingPackages from './about/page'

import Footer from './components/Footer'




const page = () => {
  return (
    <>
    <Navbar />
    <MainHerro />
    <PropertyType />
    <OurAward />
    <Location />
    <FeatureAgent/>
    <PricingPackages />
    <Footer />

      
    </>
  )
}

export default page
