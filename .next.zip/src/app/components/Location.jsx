'use client';

import React from 'react';
import { Poppins } from 'next/font/google';

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '600', '700'], // Ensure 400 and 600 included
});

const ExploreLocations = () => {
  const locations = [
    {
      id: 1,
      title: 'New Orleans, Louisiana',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'New Orleans cityscape with tall buildings and trees'
    },
    {
      id: 2,
      title: 'Jersey, United State',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'Jersey coastal view with beach and buildings'
    },
    {
      id: 3,
      title: 'Liverpool, London',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'Liverpool waterfront with modern hotel building'
    },
    {
      id: 4,
      title: 'NewYork, United States',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'New York City skyline with river view'
    },
    {
      id: 5,
      title: 'Montreal, Canada',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'Montreal city park with modern buildings in background'
    },
    {
      id: 6,
      title: 'California, USA',
      villas: 12,
      offices: 7,
      apartments: 10,
      image: '/api/placeholder/400/300',
      imageAlt: 'California urban street with tall buildings'
    }
  ];

  return (
    <div className={`${poppins.className} bg-gray-50 py-16 px-4`}>
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 mb-4">
            Explore By Location
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto leading-relaxed font-normal">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna 
            aliqua. Ut enim ad minim veniam.
          </p>
        </div>

        {/* Locations Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {locations.map((location) => (
            <div
              key={location.id}
              className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
            >
              {/* Background Image */}
              <div className="relative h-64 bg-gradient-to-br from-blue-400 to-blue-600">
                <div className="absolute inset-0 bg-black bg-opacity-30 group-hover:bg-opacity-40 transition-all duration-300" />
                
                {/* Content Overlay */}
                <div className="absolute inset-0 flex flex-col justify-center items-center text-white p-6">
                  <h3 className="text-xl md:text-2xl font-semibold mb-4 text-center">
                    {location.title}
                  </h3>
                  
                  {/* Stats */}
                  <div className="flex items-center justify-center space-x-6 text-sm">
                    <div className="flex items-center space-x-1">
                      <span className="font-semibold">{location.villas}</span>
                      <span className="opacity-90 font-normal">Villas</span>
                    </div>
                    <div className="w-px h-4 bg-white opacity-50" />
                    <div className="flex items-center space-x-1">
                      <span className="font-semibold">{location.offices}</span>
                      <span className="opacity-90 font-normal">Offices</span>
                    </div>
                    <div className="w-px h-4 bg-white opacity-50" />
                    <div className="flex items-center space-x-1">
                      <span className="font-semibold">{location.apartments}</span>
                      <span className="opacity-90 font-normal">Apartments</span>
                    </div>
                  </div>
                </div>

                {/* Hover Effect Border */}
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-blue-400 transition-all duration-300 rounded-xl" />
              </div>
            </div>
          ))}
        </div>

    
      </div>
    </div>
  );
};

export default ExploreLocations;
