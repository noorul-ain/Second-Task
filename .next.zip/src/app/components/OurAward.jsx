'use client';

import React from 'react';
import { Poppins } from 'next/font/google';

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '700'],
});

const AwardsSection = () => {
  const awards = [
    {
      icon: '🏆',
      count: '32 M',
      title: 'Blue Burmin Award',
    },
    {
      icon: '💼',
      count: '43 M',
      title: 'Mimo XII Award',
    },
    {
      icon: '💡',
      count: '51 M',
      title: 'Australian UGC Award',
    },
    {
      icon: '❤️',
      count: '42 M',
      title: 'ITCA Green Award',
    },
  ];

  return (
    <div className={`${poppins.className} bg-[#122947] py-16 px-4`}>
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="text-green-400 text-sm font-normal mb-2">
            Our Awards
          </p>
          <h2 className="text-white text-[30px] font-normal leading-normal">
            Over 1,24,000+ Happy User Being With Us Still They Love Our
            <br />
            Services
          </h2>
        </div>

        {/* Awards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {awards.map((award, index) => (
            <div key={index} className="text-center">
              {/* Icon Circle */}
              <div className="mb-6">
                <div className="bg-[#2A3F5A] w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <span className="text-white text-2xl">{award.icon}</span>
                </div>
              </div>

              {/* Count */}
              <div className="mb-2">
                <span className="text-white text-4xl md:text-5xl font-bold">
                  {award.count}
                </span>
              </div>

              {/* Award Title */}
              <p className="text-gray-300 text-sm md:text-base font-normal">
                {award.title}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AwardsSection;
