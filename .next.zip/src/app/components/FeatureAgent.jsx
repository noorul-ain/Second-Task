import React from 'react';
import { MapPin, Facebook, Linkedin, Twitter, Instagram, MessageCircle, Phone } from 'lucide-react';

export default function FeatureAgents() {
  const agents = [
    {
      id: 1,
      name: "Sargam S. Singh",
      location: "Liverpool, Canada",
      listings: "30 Listings",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face",
      verified: true
    },
    {
      id: 2,
      name: "Harijeet M. Siller",
      location: "Montreal, Canada",
      listings: "70 Listings",
      image: "https://images.unsplash.com/photo-1494790108755-2616b9c8a4c5?w=200&h=200&fit=crop&crop=face",
      verified: true
    },
    {
      id: 3,
      name: "Anna K. Young",
      location: "Denever, USA",
      listings: "80 Listings",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop&crop=face",
      verified: true
    }
  ];

  return (
    <div className="py-20 bg-white" style={{ fontFamily: 'Poppins, sans-serif', fontWeight: 400 }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl text-gray-800 mb-6" style={{ fontWeight: 600 }}>
            Our Featured Agents
          </h2>
          <p className="text-gray-500 text-lg max-w-3xl mx-auto leading-relaxed">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna<br />
            aliqua. Ut enim ad minim veniam.
          </p>
        </div>
        
        {/* Agents Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {agents.map((agent) => (
            <div
              key={agent.id}
              className="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-lg transition-all duration-300 p-8 text-center relative"
            >
              {/* Listings Badge */}
              <div className="absolute top-6 left-6 bg-orange-500 text-white px-4 py-2 rounded-full text-sm font-medium">
                {agent.listings}
              </div>
              
              {/* Agent Photo */}
              <div className="relative mb-6 mt-8">
                <div className="w-24 h-24 mx-auto rounded-full overflow-hidden border-4 border-white shadow-lg relative">
                  <img 
                    src={agent.image} 
                    alt={agent.name}
                    className="w-full h-full object-cover"
                  />
                  {/* Verification Badge */}
                  {agent.verified && (
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                      <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Location */}
              <div className="flex items-center justify-center text-gray-500 text-sm mb-3">
                <MapPin className="w-4 h-4 mr-1 text-gray-400" />
                {agent.location}
              </div>
              
              {/* Agent Name */}
              <h3 className="text-xl text-gray-800 mb-6" style={{ fontWeight: 500 }}>
                {agent.name}
              </h3>
              
              {/* Social Media Icons */}
              <div className="flex justify-center space-x-4 mb-8">
                <button className="w-10 h-10 bg-gray-50 hover:bg-gray-100 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110">
                  <Facebook className="w-5 h-5 text-gray-600" />
                </button>
                <button className="w-10 h-10 bg-gray-50 hover:bg-gray-100 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110">
                  <Linkedin className="w-5 h-5 text-gray-600" />
                </button>
                <button className="w-10 h-10 bg-gray-50 hover:bg-gray-100 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110">
                  <Twitter className="w-5 h-5 text-gray-600" />
                </button>
                <button className="w-10 h-10 bg-gray-50 hover:bg-gray-100 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110">
                  <Instagram className="w-5 h-5 text-gray-600" />
                </button>
              </div>
              
              {/* Action Buttons */}
              <div className="flex gap-4">
                <button className="flex-1 bg-green-500 hover:bg-green-600 text-white py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center text-sm font-medium shadow-sm hover:shadow-md">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Message
                </button>
                <button className="flex-1 bg-gray-900 hover:bg-black text-white py-3 px-6 rounded-lg transition-all duration-200 flex items-center justify-center text-sm font-medium shadow-sm hover:shadow-md">
                  <Phone className="w-4 h-4 mr-2" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}