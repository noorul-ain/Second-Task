'use client';

import React, { useState } from 'react';
import { Search, ChevronDown } from 'lucide-react';
import { Poppins } from 'next/font/google';

// Import Poppins with weights 400 and 600
const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '600'],

});


export default function RealEstateSearch() {
  const [location, setLocation] = useState('');
  const [propertyType, setPropertyType] = useState('Property Type');
  const [priceRange, setPriceRange] = useState('Price Range');

  const handleSearch = () => {
    console.log('Search:', { location, propertyType, priceRange });
  };

  return (
    <div className={`${poppins.className} min-h-screen relative overflow-hidden`}>
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900"></div>

      {/* Living room interior and decorations (same as before)... */}
      {/* ... [You can keep your previous interior scene code here] ... */}

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 pt-16">
        {/* Header */}
        <div className="text-center mb-12 max-w-2xl">
          <h1 className="text-5xl md:text-6xl text-white mb-6 tracking-wide font-semibold">
            Search Your Next Home
          </h1>
          <p className="text-lg text-slate-300 tracking-wide font-normal">
            Find new & featured property located in your local city.
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-lg shadow-xl p-4 w-full max-w-5xl">
          <div className="flex flex-col md:flex-row gap-3 items-end">
            {/* Location */}
            <div className="flex-1">
              <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">City/Street</div>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Location"
                className="w-full px-3 py-3 border-none focus:outline-none text-slate-1000 placeholder-slate-400 text-sm font-normal"
              />
            </div>

            <div className="hidden md:block h-12 w-px bg-slate-200"></div>

            {/* Property Type */}
            <div className="flex-1">
              <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">Property Type</div>
              <div className="relative">
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  className="w-full px-3 py-3 border-none focus:outline-none text-slate-800 appearance-none cursor-pointer text-sm font-normal"
                >
                  <option value="Property Type">Property Type</option>
                  <option value="House">House</option>
                  <option value="Apartment">Apartment</option>
                  <option value="Condo">Condo</option>
                  <option value="Townhouse">Townhouse</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
              </div>
            </div>

            <div className="hidden md:block h-12 w-px bg-slate-200"></div>

            {/* Price Range */}
            <div className="flex-1">
              <div className="text-xs text-slate-500 mb-1 uppercase tracking-wide">Price Range</div>
              <div className="relative">
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  className="w-full px-3 py-3 border-none focus:outline-none text-slate-800 appearance-none cursor-pointer text-sm"
                  style={{ fontFamily: 'Arial, sans-serif', fontWeight: 400 }}
                >
                  <option value="Property Type">Property Type</option>
                  <option value="House">House</option>
                  <option value="Apartment">Apartment</option>
                  <option value="Condo">Condo</option>
                  <option value="Townhouse">Townhouse</option>
                </select>

                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4 pointer-events-none" />
              </div>
            </div>

            <div className="hidden md:block h-12 w-px bg-slate-200"></div>

            {/* Advance Filter Button */}
            {/* Advance Filter Button */}
            <div className="flex-shrink-0">
              <button
                className={`${poppins.className} px-4 py-3 text-black text-base font-medium transition-colors duration-200 whitespace-nowrap hover:text-slate-800`}
              >
                Advance Filter
              </button>
            </div>


            {/* Search Button */}
            <button
              onClick={handleSearch}
              className="px-6 py-3 bg-green-500 hover:bg-green-600 text-white rounded-md transition-all duration-200 hover:shadow-md flex items-center justify-center"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
